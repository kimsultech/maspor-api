-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 24, 2020 at 02:46 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id13887120_maspordatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `masyarakat`
--

CREATE TABLE `masyarakat` (
  `nik` char(16) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(32) NOT NULL,
  `telp` varchar(15) NOT NULL,
  `foto_profile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `masyarakat`
--

INSERT INTO `masyarakat` (`nik`, `nama`, `username`, `password`, `telp`, `foto_profile`) VALUES
('050505', 'Kim Sultan', 'sultan', 'sultan', '088218614290', 'default.png'),
('12312312', 'kim', 'kim', 'kim', '882818282773', 'foto_1592873367082.jpg'),
('31313131', 'Test Masyarakat ubah', 'masyarakat', 'masyarakat', '088888888', 'foto_1592903194530.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `pengaduan`
--

CREATE TABLE `pengaduan` (
  `id_pengaduan` int(22) NOT NULL,
  `tgl_pengaduan` date NOT NULL,
  `nik` char(16) NOT NULL,
  `isi_laporan` text NOT NULL,
  `foto` varchar(255) NOT NULL,
  `status` enum('0','proses','selesai') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pengaduan`
--

INSERT INTO `pengaduan` (`id_pengaduan`, `tgl_pengaduan`, `nik`, `isi_laporan`, `foto`, `status`) VALUES
(31, '2020-05-30', '31313131', 'Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar \n\nMengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar Mengetest Isi Laporan dengan Memasukkan Gambar', 'gambar_1590788137001.jpg', 'selesai'),
(32, '2020-05-30', '31313131', 'Mengetest Isi Laporan Tanpa Gambar Mengetest Isi Laporan Tanpa Gambar Mengetest Isi Laporan Tanpa Gambar Mengetest Isi Laporan Tanpa Gambar Mengetest Isi Laporan Tanpa Gambar Mengetest Isi Laporan Tanpa Gambar \n\nMengetest Isi Laporan Tanpa Gambar Mengetest Isi Laporan Tanpa Gambar Mengetest Isi Laporan Tanpa Gambar \n\n\nMengetest Isi Laporan Tanpa Gambar Mengetest Isi Laporan Tanpa Gambar Mengetest Isi Laporan Tanpa Gambar Mengetest Isi Laporan Tanpa Gambar Mengetest Isi Laporan Tanpa Gambar Mengetest Isi Laporan Tanpa Gambar', 'tanpagambar', 'selesai'),
(33, '2020-05-30', '050505', 'Test Lagi', 'tanpagambar', '0'),
(34, '2020-06-23', '12312312', 'test', 'tanpagambar', 'proses'),
(35, '2020-06-23', '12312312', 'Error on Python module', 'gambar_1592873561198.jpg', '0'),
(36, '2020-06-23', '31313131', 'isidndjdjnsjshdjdjdbjdjdjddjd', 'tanpagambar', '0'),
(37, '2020-06-23', '31313131', 'test dengan gambar', 'gambar_1592903359956.jpg', '0');

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE `petugas` (
  `id_petugas` int(11) NOT NULL,
  `nama_petugas` varchar(35) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(32) NOT NULL,
  `telp` varchar(15) NOT NULL,
  `level` enum('admin','petugas') NOT NULL,
  `foto_petugas` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`id_petugas`, `nama_petugas`, `username`, `password`, `telp`, `level`, `foto_petugas`) VALUES
(1, 'petugas 1', 'petugas', 'petugas', '082616252726', 'petugas', 'foto_1590789195525.jpg'),
(2, 'administrasi 01', 'admin', 'admin', '0826272626661', 'admin', 'foto_1590787444122.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tanggapan`
--

CREATE TABLE `tanggapan` (
  `id_tanggapan` int(11) NOT NULL,
  `id_pengaduan` int(11) NOT NULL,
  `tgl_tanggapan` date NOT NULL,
  `tanggapan` text NOT NULL,
  `id_petugas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tanggapan`
--

INSERT INTO `tanggapan` (`id_tanggapan`, `id_pengaduan`, `tgl_tanggapan`, `tanggapan`, `id_petugas`) VALUES
(16, 31, '2020-05-30', 'test Tanggapan', 1),
(17, 32, '2020-05-30', 'test Tanggapan 2', 1),
(18, 34, '2020-06-23', 'tanggapan', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `masyarakat`
--
ALTER TABLE `masyarakat`
  ADD PRIMARY KEY (`nik`);

--
-- Indexes for table `pengaduan`
--
ALTER TABLE `pengaduan`
  ADD PRIMARY KEY (`id_pengaduan`),
  ADD KEY `nik` (`nik`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`id_petugas`);

--
-- Indexes for table `tanggapan`
--
ALTER TABLE `tanggapan`
  ADD PRIMARY KEY (`id_tanggapan`),
  ADD KEY `id_pengaduan` (`id_pengaduan`),
  ADD KEY `id_petugas` (`id_petugas`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pengaduan`
--
ALTER TABLE `pengaduan`
  MODIFY `id_pengaduan` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `petugas`
--
ALTER TABLE `petugas`
  MODIFY `id_petugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1231223;

--
-- AUTO_INCREMENT for table `tanggapan`
--
ALTER TABLE `tanggapan`
  MODIFY `id_tanggapan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pengaduan`
--
ALTER TABLE `pengaduan`
  ADD CONSTRAINT `pengaduan_ibfk_1` FOREIGN KEY (`nik`) REFERENCES `masyarakat` (`nik`);

--
-- Constraints for table `tanggapan`
--
ALTER TABLE `tanggapan`
  ADD CONSTRAINT `tanggapan_ibfk_1` FOREIGN KEY (`id_pengaduan`) REFERENCES `pengaduan` (`id_pengaduan`),
  ADD CONSTRAINT `tanggapan_ibfk_2` FOREIGN KEY (`id_petugas`) REFERENCES `petugas` (`id_petugas`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
